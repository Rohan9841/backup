var boxClass = 'movingDiv';

// define functions in this file

function outputBox(num){
  box = "<div class = '" + boxClass + "' id = 'div"+num+"'>";
}
