/* try the different advanced selection calls here */

//$(':password').css('background-color',	'yellow');

$('form	:nth-child(4n)').css('background-color',	'yellow');

$('label:contains("word")').css("color",	"black");