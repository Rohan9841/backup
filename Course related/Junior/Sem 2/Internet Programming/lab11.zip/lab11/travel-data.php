<?php
  $postId1 = 1;
  $userId1 = 2;
  $userName1 = "Leonie K�hler";
  $date1 = "2/4/2011";
  $thumb1 = "6592294487.jpg";
  $title1 = "Calgary in the Snow";
  $excerpt1 = "In December of 2011, I was lucky/unfortunate enough to have the opportunity to fly to chilly Calgary in Western Canada for a week-long conference.";
  
  $postId2 = 3;
  $userId2 = 5;
  $userName2 = "Frantisek  Wichterlov�";
  $date2 = "9/3/2011";
  $thumb2 = "6114904363.jpg";
  $title2 = "Mountain Climbing";
  $excerpt2 = "The highlight of our last trip to Canada was a climb up Sulpher Mountain just outside of Banff. I'd like to say that it was so difficult that we required crampons, pitons, and screamers but that would be stretching the truth for sure.";

  $postId3 = 9;
  $userId3 = 13;
  $userName3 = "Edward Francis";
  $date3 = "3/19/2012";
  $thumb3 = "5856697109.jpg";
  $title3 = "Nova Scotia";
  $excerpt3 = "The steamer Mongolia, belonging to the Peninsular and Oriental Company, built of iron, of two thousand eight hundred tons burden, and five hundred horse-power, was due at eleven o'clock a.m. on Wednesday, the 9th of October, at Suez.";  
  
?>