// Name: Rohan Maharjan | Date Assigned: 09/04/2017
//
// Course: CSCI 2073    | Date Due: 09/15/2017
//
// Instructor: Dr. Cordova
//
// File name: Archer.java
//
// Program Description: This is a sub class of GameCharacter class 


public class Archer extends GameCharacter
{
   /**
      argument constructor that passes its arguments to super constructor
      @param name for name of archer
      @param x for x co-ordinate of the archer
      @param y for y co-ordinate of the archer
   */
   public Archer(String name, int x, int y)
   {
      super(name, x, y);
   }
   
   /**
      Override move method from superclass to move the character in certain direction for certain distance
      @param direction gives direction to move the character
      @param distance tells how much distance should the character move
   */
   @Override
   public void move (char direction, int distance)
   {
      int x = getX();
      int y = getY();
      
      if (this.getHealthPoints()>=10)
      {
         if (distance<0)
         {
            distance = 0;
         }
         
         if (distance>5)
         {
            distance = 5;
         }
         
         if (direction == 'N')
         {
            y += distance;
         }
         else if (direction == 'S')
         {
            y -= distance;
         }
         else if (direction == 'E')
         {
            x += distance;
         }
         else if (direction == 'W')
         {
            x -= distance;
         }
         
         if (x<0)
         {
            x = 0;
         }
         
         if (y<0)
         {
            y = 0;
         }
         
         setX(x);
         setY(y);
      }   
   }
   
   /**
      Override attack method from super class to attack a target 
      @param target gives the target which is being attacked
   */
   @Override
   public boolean attack(GameCharacter target)
   {
      int archerPosX = this.getX();
      int archerPosY = this.getY();
      int targetPosX = target.getX();
      int targetPosY = target.getY();
      int targetHealth = target.getHealthPoints();
      
      if(Math.sqrt(Math.pow((targetPosX-archerPosX),2)+Math.pow((targetPosY-archerPosY),2)) < 30 && this.getHealthPoints()>=10)
      {
         if (targetHealth >= 10)
         {
            targetHealth -= 10;
         }   
         
         else if (targetHealth >=0 && targetHealth < 10)
         {
            targetHealth = 0;
         }
         
         target.setHealthPoints(targetHealth);
         
         return true;
      }
      
     else
     {
         return false;
     }
     
   }
   
   /**
      Overriding toString method from superclass to display required output
   */
   @Override
   public String toString()
   {
      return("Archer "+super.toString());
      
   }
}