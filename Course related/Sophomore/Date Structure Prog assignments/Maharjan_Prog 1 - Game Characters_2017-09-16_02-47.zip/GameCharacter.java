// Name: Rohan Maharjan | Date Assigned: 09/04/2017
//
// Course: CSCI 2073    | Date Due: 09/15/2017
//
// Instructor: Dr. Cordova
//
// File name: GameCharacter.java
//
// Program Description: This is an abstract super class to define the attributes of each game character. It has a constructor and methods that will be used in its sub class.


public abstract class GameCharacter
{
   /**
      instance variables
   */ 
   private String nameOfCharacter;
   private int x;
   private int y;
   private int healthPoints = 100;
   
   /**
      argument constructor
      @param name for name of the character
      @param xCoordinate for x position of the character
      @param yCoordinate for y position of the character
   */
   public GameCharacter(String name, int xCoordinate, int yCoordinate)
   {
      nameOfCharacter = name;
      x = xCoordinate;
      y = yCoordinate;
   }
   
   /**
      method to access name of the character
      @return nameOfCharacter
   */
   public String getName()
   {
      return nameOfCharacter;
   }
   
   /**
      method to access x position of the character
      @return x
   */
   public int getX()
   {
      return x;
   }
   
   /**
      method to access y position of the character
      @return y
   */
   public int getY()
   {
      return y;
   }
   
   /**
      method to access healthPoints of the character
      @return healthPoints gives the health points of the character
   */
   public int getHealthPoints()
   {
      return healthPoints;
   }
   
   /**
      method to set health points of the character
      @param h tells the health point of the character to be set
   */
   public void setHealthPoints(int h)
   {
      healthPoints = h;
   }
   
   /**
      method to set x position of the character
      @param a gives the x co-ordinate of the character
   */
   public void setX(int a)
   {
      x = a;
   }
   
   /**
      method to set y position of the character
      @param b gives the y co-ordinate of the character
   */
   public void setY(int b)
   {
      y = b;
   }
   
   /**
      abstract method to move the character
      @param dir gives the direction to move the character
      @param dis tells how much distance should the character move
   */
   public abstract void move(char dir, int dis);
   
   /**
      abstract method to attack the character
      @param target gives the target that is being attacked
      @return boolean value
   */
   public abstract boolean attack(GameCharacter target);
   
   /**
      toString method to display information of characters
      @return strings
   */
   public String toString()
   {
      return(nameOfCharacter+" is left with "+healthPoints+" points at position "+"("+x+","+y+")");
   } 
}