/**
   Name: Rohan Maharjan | Date Assigned: 09/25/2017
   
   Course: CSCI 2073    | Date Due: 10/06/2017
   
   Instructor: Dr. Cordova
   
   File name: WordList.java
   
   Program Description: This class uses an arraylist to store collection of string objects. 
                        It contains different constructors and methods that uses the object
                        stored in the list.

*/

/**
   importing java packages
*/   
import java.util.*;
import  java.io.*;

public class WordList
{
   /**
      new arrayList that will contain list of string objects
   */   
   List<String> myList = new ArrayList<>();
   
   /**
      instance variable
   */
   private int counter = 0;
   
   /**
      no-argument constructor
   */   
   public WordList()
   {
      myList.add("");
   }
   
   /**
      argument constructor
      @param array the objects in the array will be stored in the array list.
   */   
   public WordList(String[] array)
   {
      for (int i = 0; i<array.length; i++)
      {
         myList.add(array[i]);
         counter += 1;
      }   
   }
   
   /**
      method to read words from a file
      @param filename This file will be read
      @return 'True' if file is read. 'False' if failed to read
   */
   public boolean readWords(String filename)
   {
      try
      {
         File infile = new File(filename);
         Scanner in = new Scanner(infile);
         String word = "";
         
         myList.set(0,in.next());
         counter += 1;
         
         while (in.hasNext())
         {
            word = in.next();   
            myList.add(word);
            counter += 1;        
         } 
      
         return true;
      }
      
      catch(FileNotFoundException exception)
      {
         System.out.print("No words to read.");
         
      }  
      return false;
   }
   
   /**
      method to count the total number of words in the list
      @return total number of words in the list
   */
   public int count()
   {
      return(counter);
   }
   
   /**
      method to count the total occurence of a word in the list
      @param target this word will be searched in the list
      @return total number of times the target is stored in the list
   */
   public int count(String target)
   {
      String targetUpper = target.toUpperCase();
      int targetCounter = 0;
                          
      for (String each: myList)
      {
         String scannedWord = "";
            
         String wordUpper = each.toUpperCase();
            
         try{
            for(int i = 0; i<targetUpper.length();i++)
            {
               char character = wordUpper.charAt(i);
               scannedWord += character;
                  
            }
               
         }
            
         catch(StringIndexOutOfBoundsException ex)
         {
            
         }
            
         finally{
               
            int asciiValue = 0;
               
            if(wordUpper.length() > targetUpper.length())
            {
               asciiValue = (int)(wordUpper.charAt(scannedWord.length()));
            }
               
            if (scannedWord.equals(targetUpper) && (asciiValue<65||asciiValue>90))
            {
               targetCounter += 1;
            }
         }   
            
      }
      return targetCounter;
   }   
   
   /**
      method to replace old word with  a new word
      @param old this is an old word
      @param newWord this word will replace the old word
      @param ignoreCase this parameter determines if the case of the word should be ignored or not while replacing it
      @return total number of replacements made
   */    
   public int replace(String old, String newWord, boolean ignoreCase)
   {
      int replaceCounter = 0;
      
      if (ignoreCase == true)
      {
         String oldUpper = old.toUpperCase();
                          
         for (String each: myList)
         {
            String scannedWord = "";
            
            String wordUpper = each.toUpperCase();
            
            try{
               for(int i = 0; i<oldUpper.length();i++)
               {
                  char character = wordUpper.charAt(i);
                  scannedWord += character;
                  
               }
               
            }
            
            catch(StringIndexOutOfBoundsException ex)
            {
            
            }
            
            finally{
               
               int asciiValue = 0;
               char punctuation = ' ';
               
               if(wordUpper.length() > oldUpper.length())
               {
                  punctuation = wordUpper.charAt(scannedWord.length());
                  asciiValue = (int)(punctuation);
               }
               
               if (scannedWord.equals(oldUpper) && (asciiValue<65||asciiValue>90))
               {
                  int indexOfWord = myList.indexOf(each);
                  replaceCounter += 1;
                  myList.set(indexOfWord,newWord+wordUpper.substring(scannedWord.length(),wordUpper.length()));
               }
            }   
            
         }
        
      }
      
      else if (ignoreCase == false)
      {
         for (String each: myList)
         {
            String scannedWord = "";
            
            try{
               for(int i = 0; i<old.length();i++)
               {
                  char character = each.charAt(i);
                  scannedWord += character;
                  
               }
               
            }
            
            catch(StringIndexOutOfBoundsException ex)
            {
               
            }
            
            finally{
               
               int asciiValue = 0;
               char punctuation = ' ';
               
               if(each.length() > old.length())
               {
                  punctuation = each.charAt(scannedWord.length());
                  asciiValue = (int)(punctuation);
               }
               
               if (scannedWord.equals(old) && (asciiValue<65||(asciiValue>90 && asciiValue<97)||asciiValue>122 ))
               {
                  int indexOfWord = myList.indexOf(each);
                  replaceCounter += 1;
                  myList.set(indexOfWord,newWord+each.substring(scannedWord.length(),each.length()));
               }
            }  
         }
      }
      return replaceCounter;
   }
   
   /**
      method to display the contents of the list in different lines
      @param wordsPerLine determines the number of words to be displayed in a line
      @return number of lines displayed
   */
   public int display(int wordsPerLine)
   {
      int lineCounter = 1;
      String wordsInLine = "";
      
      try{
         for(int i = 0; i<myList.size(); i += wordsPerLine)
         {
         
            for (int j = i; j<wordsPerLine+i; j++)
            {
               wordsInLine = myList.get(j);   
               System.out.print(wordsInLine+" ");
            }
            lineCounter += 1;
            System.out.println("");
         }
          
      }
      
      catch(IndexOutOfBoundsException exception)
      {
         lineCounter = lineCounter;
      }
      System.out.println("\n");
      return lineCounter;
   }
   
   /**
      method to return all the contents of the list, surrounded by brackets
      @return all the words, separated by space, and enclosed by brackets
   */
   public String toString()
   {
      String bracket = "[";
      String words = "";
      for (int i = 0; i<myList.size()-1; i++)
      {
         words += myList.get(i)+" ";
      }   
      
      String lastWord = myList.get(myList.size()-1);
      
      return("["+words+lastWord+"]");
   }
   
}         
                    

      
