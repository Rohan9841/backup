/**
   Name: Rohan Maharjan | Date Assigned: 10/23/2017
   
   Course: CSCI 2073    | Date Due: 11/03/2017
   
   Instructor: Dr. Cordova
   
   File name: Browser.java
   
   Program Description: This program simulates the navigational tools of an internet browser, using
                        Stack object(s) to keep track of the sites visited.

*/

/**
   importing java packages
*/
import java.util.*;
import java.io.*;
import java.net.URL;

public class Browser
{
   /**
      stack object
   **/
   LinkedStack<String> urlTracker = new LinkedStack<>();
   
   /**
      stack object
   **/
   LinkedStack<String>historyTracker = new LinkedStack<>();
   
   /**
      stack object
   **/
   StackInt<String> temp1 = new LinkedStack<>();

   /**
      instance variable
   **/
   public String currentURL;
   
   /**
      no-argument constructor
   **/
   public Browser()
   {
      currentURL = "http://www.ulm.edu"; 
      urlTracker.push(currentURL);
      historyTracker.push(currentURL);
   }
   
   /**
      argument constructor
      @param constructorURL this is used as an argument in load method
   **/
   public Browser(String constructorURL)
   {
      load(constructorURL);
   }
   
   /**
      method to load the webpage with the URL passed as argument.
      @param url This URL will be loaded
      @return 'True' if the URL is loaded. 'False' if failed to load the URL.
   **/
   public boolean load(String url)
   {
      try
      {
         URL webpage = new URL(url);
         if(webpage.getContent() != null)
         {
            currentURL = url;
            historyTracker.push(currentURL);
            urlTracker.push(currentURL);
            while(!temp1.empty())
            {
               temp1.pop();
            }
            return true;
         }
      }
      
      catch (Exception e)
      {
         currentURL = "ERROR: CANNOT FIND "+url;    
         urlTracker.push(currentURL);
         return false;
      }
      currentURL = "ERROR: CANNOT FIND "+url;    
      urlTracker.push(currentURL);

      return false;
      
   }
   
   /**
      method to return the current page 
      @return The current URL that is being used
   **/
   public String currentPage()
   {
      return (currentURL);
   }
   
   /**
      method to check if we can go back to the previous page
      @return 'True' if we can go back. 'False' if we cannot.
   **/
   public boolean canGoBack()
   {
      if(!urlTracker.empty())
      {
         temp1.push(urlTracker.pop());
         if(!urlTracker.empty())
         {
            urlTracker.push(temp1.pop());
            return true;
         }
         urlTracker.push(temp1.pop());
      }
      return false;
   }
   
   /**
      method to go back to the previous page
      @return previously loaded page
   **/
   public String goBack()
   {
      if (canGoBack())
      {
         temp1.push(urlTracker.pop());
         
         currentURL = urlTracker.peek(); 
               
         return currentURL;
         
      }
      return currentURL;  
   }
   
   /**
      method to check if we can go forward to the already loaded page
      @return 'True' if we can go forward. 'False' if we cannot.
   **/
   public boolean canGoForward()
   {
      return (!temp1.empty());
   }
   
   /**
      method to go forward to the next page
      @return the next page that has already been loaded
   **/
   public String goForward()
   {
      if (canGoForward())
      {
         urlTracker.push(temp1.pop());
         currentURL = urlTracker.peek();
         return currentURL;
         
      }
      return currentURL;
   }
   
   /**
      method to display history of previously loaded pages
      @return the list of pages that were previously loaded
   **/
   public String history()
   {
      StackInt<String>temp2 = new LinkedStack<>();
      String displayHistory = "";
      
      while(!historyTracker.empty())
      {
         temp2.push(historyTracker.peek());
         displayHistory += historyTracker.pop()+"\n";
      }
      
      while (!temp2.empty())
      {
         historyTracker.push(temp2.pop());
      }
      
      return displayHistory;
   }
   
}